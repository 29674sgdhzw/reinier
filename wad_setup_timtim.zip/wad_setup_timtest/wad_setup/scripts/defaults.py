LOGGERNAME = 'wad_setup'
