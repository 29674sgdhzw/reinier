A shell wrapper wad_setup.sh that finds the correct python to use.
One python file scripts/wad_setup.py to run different setup recipes.
A recipe is a json script, outlining what steps to take.
