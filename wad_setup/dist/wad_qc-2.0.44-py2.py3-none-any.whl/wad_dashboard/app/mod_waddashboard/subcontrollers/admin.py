# Import flask dependencies
from flask import Blueprint, request, render_template, \
     flash, session, redirect, url_for, Markup

try:
    from app.mod_auth.controllers import login_required
    from app.libs.shared import dbio_connect
    from app.libs import html_elements
    from ..models import WDUsers, role_names, WDUserGroups, WDMainGroups, WDMainItems, WDSections, WDSubGroups, WDSubItems, WDUserTags
except ImportError:
    from wad_dashboard.app.mod_auth.controllers import login_required
    from wad_dashboard.app.libs.shared import dbio_connect
    from wad_dashboard.app.libs import html_elements
    from wad_dashboard.app.mod_waddashboard.models import WDUsers, role_names, WDUserGroups, WDMainGroups, WDMainItems, WDSections, WDSubGroups, WDSubItems, WDUserTags
dbio = dbio_connect()
import os.path
from wad_qc.connection import bytes_as_string

# Import modify forms
from .forms_group import GroupForm, SectionForm, SubGroupForm
from .forms_usergroup import UserGroupForm
from .forms_usertags import UserTagForm

# Define the blueprint: 'auth', set its url prefix: app.url/auth
mod_blueprint = Blueprint('admin', __name__, url_prefix='/admin')

# Set the route and accepted methods
@mod_blueprint.route('/default', methods=['GET'])
@login_required
def default():
    """
    Just present a menu with choices; should all be require authorization
    """
    # not everything for normal users
    role = 2
    if session.get('logged_in'):
        role = session.get('role')

    adminrole = (role == 0)

    menus = [
    ]
    
    groupingmenu=[
        { 'label':'Sections', 'href':url_for('admin.sections') }, 
        { 'label':'MainGroups', 'href':url_for('admin.groups') },
        { 'label':'SubGroups', 'href':url_for('admin.subgroups') },
    ]

    displaymenu=[
        { 'label':'Results', 'href':url_for('display.default') }, 
    ]

    resourcesmenu=[
        { 'label':'User Management', 'href':url_for('auth_users.default') },
        { 'label':'Licenses', 'href':url_for('admin.licenses') }, 
    ]

    # not for normal users
    if role==0: 
        displaymenu.append( { 'label':'User visible MainGroups/Tags', 'href':url_for('admin.usergroups') } )
        
        menus.append({'title':'Grouping', 'items':groupingmenu})

    if role<2:
        menus.append({'title':'Display', 'items':displaymenu})

    menus.append({'title':'Resources', 'items':resourcesmenu})
    return render_template('waddashboard/home.html', menus=menus, title='WAD-QC Dashboard Admin Menu')

@mod_blueprint.route('/licenses')
@login_required
def licenses():
    # show the licenses of the various pieces of software included

    link = html_elements.Link(label="Flask", href="http://flask.pocoo.org/", target="_blank")
    subtitle = "WAD-Dashboard is a {} app, and makes use of these additional pieces of open source software.".format(link)

    table_rows = []
    table_rows.append(["Bootstrap", 
                       html_elements.Link(label="https://getbootstrap.com/", href="https://getbootstrap.com/", target="_blank"), 
                       html_elements.Link(label="MIT", href=url_for('static', filename='licenses/bootstrap/LICENSE.txt'))])

    table_rows.append(["tablesorter", 
                       html_elements.Link(label="https://mottie.github.io/tablesorter/", href="https://mottie.github.io/tablesorter/", target="_blank"), 
                       html_elements.Link(label="MIT", href=url_for('static', filename='licenses/tablesorter/LICENSE.txt'))])

    table_rows.append(["CollapsibleLists", 
                       html_elements.Link(label="http://code.iamkate.com/javascript/collapsible-lists/", href="http://code.iamkate.com/javascript/collapsible-lists/", target="_blank"), 
                       html_elements.Link(label="Creative Commons 1.0 Universal", href=url_for('static', filename='licenses/collapsiblelist/LICENSE.txt'))])

    table_rows.append(["JSON Editor Online", 
                       html_elements.Link(label="http://jsoneditoronline.org/", href="http://jsoneditoronline.org/"), 
                       html_elements.Link(label="Apache License 2.0", href=url_for('static', filename='licenses/jsoneditoronline/LICENSE.txt'))])

    table = html_elements.Table(headers=['Component', 'URL', 'License'], rows=table_rows)
    
    return render_template("waddashboard/generic.html", title='Licenses', subtitle=Markup(subtitle), html=Markup(table))

@mod_blueprint.route('/sections', methods=['GET'])
@login_required
def sections():
    """
    Display and allow editing of sections table
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if role >0: 
        return(redirect(url_for('admin.default')))

    subtitle = [
        "Sections are the toplevel menus on the homepage of WAD Dashboard. They are placeholders for MainGroups.",
        "Deleting a Section will not ask for confirmation and will delete all MainGroups in that Section as well."
    ]
    stuff = WDSections.select().order_by(WDSections.name)

    table_rows = []
    for data in stuff:
        table_rows.append([data.id, data.name, data.description, 
                           data.position, len(data.maingroups),
                           html_elements.Button(label='delete', href=url_for('.deletesection', gid=data.id), _class='btn btn-danger'),
                           html_elements.Button(label='edit', href=url_for('.modifysection', gid=data.id))
                           ])

    table = html_elements.Table(headers=['id', 'name', 'description', 'position', '#maingroups'],
                                rows=table_rows,
                                _class='tablesorter-wadred', _id='sortTable')
    newbutton = html_elements.Button(label='New', href=url_for('.modifysection'))
    page = table+newbutton
    
    return render_template("waddashboard/generic.html", title='Sections', msg='', subtitle='', 
                           html=Markup(page),
                           inpanel={'type': "panel-info", 'title': "info", 'content':subtitle})

@mod_blueprint.route('/groups', methods=['GET', 'POST'])
@login_required
def groups():
    """
    Display and allow editing of groups table
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if role >0: 
        return(redirect(url_for('admin.default')))

    subtitle = "MainGroups are placeholders to group SubGroups."

    stuff = WDMainGroups.select().order_by(WDMainGroups.name)

    table_rows = []
    for data in stuff:
        sg = WDMainItems.select().where(WDMainItems.maingroup == data.id)
        table_rows.append([data.id, data.name, data.description, 
                           data.section.name, len(sg),
                           html_elements.Button(label='delete', href=url_for('.deletegroup', gid=data.id), _class='btn btn-danger'),
                           html_elements.Button(label='edit', href=url_for('.modifygroup', gid=data.id))
                           ])

    table = html_elements.Table(headers=['id', 'name', 'description', 'section', '#subgroups'], 
                                rows=table_rows,
                                _class='tablesorter-wadred', _id='sortTable')
    newbutton = html_elements.Button(label='New', href=url_for('.modifygroup'))
    page = table+newbutton
    
    return render_template("waddashboard/generic.html", title='MainGroups', msg='', subtitle='', 
                           html=Markup(page),
                           inpanel={'type': "panel-info", 'title': "info", 'content':subtitle})

@mod_blueprint.route('/subgroups', methods=['GET'])
@login_required
def subgroups():
    """
    Display and allow editing of subgroups table
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if role >0: 
        return(redirect(url_for('admin.default')))

    subtitle = ("SubGroups are groups of Selectors, for which the Results are joined. "  
         "MainGroups consist of SubGroups only, so even if the MainGroup is to contain " 
         "only one selector, a SubGroup should be defined for that Selector.")

    stuff = WDSubGroups.select().order_by(WDSubGroups.name)

    table_rows = []
    for data in stuff:
        mg = WDMainItems.select().where(WDMainItems.subgroup == data.id)
        table_rows.append([data.id, data.name, data.description, 
                           len(mg), len(data.subitems),
                           html_elements.Button(label='delete', href=url_for('.deletesubgroup', gid=data.id), _class='btn btn-danger'),
                           html_elements.Button(label='edit', href=url_for('.modifysubgroup', gid=data.id))
                           ])

    table = html_elements.Table(headers=['id', 'name', 'description', '#maingroups', '#selectors'], 
                                rows=table_rows,
                                _class='tablesorter-wadred', _id='sortTable')
    newbutton = html_elements.Button(label='New', href=url_for('.modifysubgroup'))
    page = table+newbutton
    
    return render_template("waddashboard/generic.html", title='SubGroups', msg='', subtitle='', 
                           html=Markup(page),
                           inpanel={'type': "panel-info", 'title': "info", 'content':subtitle})

@mod_blueprint.route('/usergroups', methods=['GET'])
@login_required
def usergroups():
    """
    Allow display of MainGroups and Tags for given users
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if not role == 0: 
        return(redirect(url_for('admin.default')))

    subtitle = "Visibility of MainGroups and Tags for Users."

    stuff = WDUsers.select().order_by(WDUsers.username)

    table_rows = []
    for data in stuff:
        if data.role == 0: #admin sees everything
            continue
        sg = WDUserGroups.select().where(WDUserGroups.user == data)
        tags = WDUserTags.select().where(WDUserTags.user == data)
        table_rows.append([data.id, data.username, 
                           role_names[data.role], len(sg), len(tags),
                           html_elements.Button(label='edit groups', href=url_for('.modifyusergroup', gid=data.id)),
                           html_elements.Button(label='edit tags', href=url_for('.modifyusertags', gid=data.id))
                           ])

    table = html_elements.Table(headers=['id', 'username', 'role', '#maingroups', '#tags'], 
                                rows=table_rows,
                                _class='tablesorter-wadred', _id='sortTable')
    
    return render_template("waddashboard/generic.html", title='User visble Groups and Tags', msg='', subtitle='', 
                           html=Markup(table),
                           inpanel={'type': "panel-info", 'title': "info", 'content':subtitle})

@mod_blueprint.route('/section/delete')
@login_required
def deletesection():
    """
    delete given id of given table from iqc db
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if role >0: 
        return(redirect(url_for('admin.default')))

    _gid = int(request.args['gid']) if 'gid' in request.args else None

    # invalid table request are to be ignored
    if not _gid is None:
        WDSections.get_by_id(_gid).delete_instance(recursive=True)

    # go back to overview page
    return redirect(url_for('.sections'))

@mod_blueprint.route('/group/delete')
@login_required
def deletegroup():
    """
    delete given id of given table from iqc db
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if role >0: 
        return(redirect(url_for('admin.default')))

    _gid = int(request.args['gid']) if 'gid' in request.args else None

    # invalid table request are to be ignored
    if not _gid is None:
        WDMainGroups.get_by_id(_gid).delete_instance(recursive=True)

    # go back to overview page
    return redirect(url_for('.groups'))

@mod_blueprint.route('/subgroup/delete')
@login_required
def deletesubgroup():
    """
    delete given id of given table from iqc db
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if role >0: 
        return(redirect(url_for('admin.default')))

    _gid = int(request.args['gid']) if 'gid' in request.args else None

    # invalid table request are to be ignored
    if not _gid is None:
        WDSubGroups.get_by_id(_gid).delete_instance(recursive=True)

    # go back to overview page
    return redirect(url_for('.subgroups'))

# Set the route and accepted methods
@mod_blueprint.route('/section/modify', methods=['GET', 'POST'])
@login_required
def modifysection():
    """
    Show a table with all details of a section
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if role >0: 
        return(redirect(url_for('admin.default')))

    _gid = int(request.args['gid']) if 'gid' in request.args else None
    _xtramsg = request.args.get('xtramsg', None)

    subtitle = None
    if _xtramsg == 'maingroup':
        subtitle = "A Main group must be part of a Section. You must define a Section first!"
    elif _xtramsg == 'subgroup':
        subtitle = "A sub group must be part of a Main group, and a Main group must be part of a Section. You must define a Section first!"
        
    # invalid table request are to be ignored
    formtitle = 'Modify section'
    form = SectionForm(None if request.method=="GET" else request.form)
    if not _gid is None:
        section = WDSections.get_by_id(_gid)
        form.gid.data = _gid
        form.name.data = section.name
        form.position.data = section.position
        form.description.data = section.description

    newentry = False
    if form.gid is None or form.gid.data == '' or form.gid.data is None: #define here, to avoid wrong label on redisplaying a form with errors
        newentry = True
        formtitle = 'New section'

    existingnames = [ s.name for s in WDSections.select() ]
    # Verify the sign in form
    valid = True
    if form.validate_on_submit():
        if newentry:
            if form.name.data in existingnames:
                flash('Section name already exists!', 'error')
                valid = False
        else:
            section = WDSections.get_by_id(int(form.gid.data))
            if not section.name == form.name.data and form.name.data in existingnames:
                flash('Section name already exists!', 'error')
                valid = False
        if valid:
            # the elements of the form
            field_dict = {k:v for k,v in request.form.items()}
            doModifySection(field_dict)
            return redirect(url_for('.sections')) #doExport(field_dict)
            
    return render_template("waddashboard/section.html", form=form, action=url_for('.modifysection'), 
                           title=formtitle, subtitle=subtitle, msg='Fill out the fields and click Submit')
    
# Set the route and accepted methods
@mod_blueprint.route('/group/modify', methods=['GET', 'POST'])
@login_required
def modifygroup():
    """
    Show a table with all details of a group
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if role >0: 
        return(redirect(url_for('admin.default')))

    # if no sections defined, first go to new section
    if len(WDSections.select()) == 0:
        _xtramsg = request.args.get('xtramsg', "maingroup")
        return redirect(url_for('.modifysection', xtramsg=_xtramsg))

    _gid = int(request.args['gid']) if 'gid' in request.args else None

    subtitle = None

    # invalid table request are to be ignored
    formtitle = 'Modify MainGroup'
    selectors = None
    subgroups = getSubgroups(_gid)
    form = GroupForm(None if request.method=="GET" else request.form, selectors=selectors, subgroups=subgroups)
    form.section.choices = sorted([(m.id, m.name) for m in WDSections.select()], key=lambda x: x[1])

    if not _gid is None:
        group = WDMainGroups.get_by_id(_gid)
        form.gid.data = _gid
        form.name.data = group.name
        form.section.data = group.section.id
        form.description.data = group.description
        
    newentry = False
    if form.gid is None or form.gid.data == '' or form.gid.data is None: #define here, to avoid wrong label on redisplaying a form with errors
        newentry = True
        formtitle = 'New MainGroup'

    existingnames = [ s.name+str(s.section.id) for s in WDMainGroups.select() ]
    # Verify the sign in form
    valid = True
    if form.validate_on_submit():
        if newentry and form.name.data+str(form.section.data) in existingnames:
            flash('MainGroup name already exists for this section!', 'error')
            valid = False
        if not newentry:
            group = WDMainGroups.get_by_id(form.gid.data)
            if not group.name == form.name.data and form.name.data+str(form.section.data) in existingnames:
                flash('MainGroup name already exists for this section!', 'error')
                valid = False
        if valid:
            # the elements of the form
            field_dict = {k:v for k,v in request.form.items()}
            doModifyGroup(field_dict)
            return redirect(url_for('.groups')) #doExport(field_dict)

    return render_template("waddashboard/group.html", form=form, action=url_for('.modifygroup'), 
                           title=formtitle, subtitle=subtitle, msg='Select SubGroups to group for main display and click Submit')

# Set the route and accepted methods
@mod_blueprint.route('/subgroup/modify', methods=['GET', 'POST'])
@login_required
def modifysubgroup():
    """
    Show a table with all details of a group
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if role >0: 
        return(redirect(url_for('admin.default')))

    _gid = int(request.args['gid']) if 'gid' in request.args else None

    # invalid table request are to be ignored
    formtitle = 'Modify SubGroup'
    selectors = sorted(getSelectors(groupid=None, subgroupid=_gid), key=lambda x: x['sel_name'])
    form = SubGroupForm(None if request.method=="GET" else request.form, selectors=selectors)
        
    if not _gid is None:
        subgroup = WDSubGroups.get_by_id(_gid)
        form.gid.data = _gid
        form.name.data = subgroup.name
        form.description.data = subgroup.description
        
    newentry = False
    if form.gid is None or form.gid.data == '' or form.gid.data is None: #define here, to avoid wrong label on redisplaying a form with errors
        newentry = True
        formtitle = 'New SubGroup'

    existingnames = [ s.name for s in WDSubGroups.select() ]
    # Verify the sign in form
    valid = True
    if form.validate_on_submit():
        if newentry:
            if form.name.data in existingnames:
                flash('SubGroup name already exists!', 'error')
                valid = False
        else:
            subgroup = WDSubGroups.get_by_id(int(form.gid.data))
            if not subgroup.name == form.name.data and form.name.data in existingnames:
                flash('SubGroup name already exists!', 'error')
                valid = False
        if valid:
            # the elements of the form
            field_dict = {k:v for k,v in request.form.items()}
            doModifySubGroup(field_dict)
            return redirect(url_for('.subgroups')) #doExport(field_dict)
            
    return render_template("waddashboard/subgroup.html", form=form, action=url_for('.modifysubgroup'), 
                           title=formtitle, msg='Select selectors to group for sub group display and click Submit')

# Set the route and accepted methods
@mod_blueprint.route('/user/modifygroups', methods=['GET', 'POST'])
@login_required
def modifyusergroup():
    """
    Show a table with MainGroups visible to each user
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if role >0: 
        return(redirect(url_for('admin.default')))

    _gid = int(request.args['gid']) if 'gid' in request.args else None

    subtitle = None

    # invalid table request are to be ignored
    formtitle = 'Modify User visible MainGroups'
    selectors = None
    groups = getUsergroups(_gid)
    form = UserGroupForm(None if request.method=="GET" else request.form, groups=groups, include_what='selection')

    if not _gid is None: # only modify
        form.gid.data = _gid # userid
        user = WDUsers.get_by_id(_gid)
    
    # Verify the sign in form
    valid = True
    if form.validate_on_submit():
        if valid:
            # the elements of the form
            field_dict = {k:v for k,v in request.form.items()}
            doModifyUserGroup(field_dict)
            return redirect(url_for('.usergroups')) #doExport(field_dict)
            
    return render_template("waddashboard/usergroup.html", form=form, action=url_for('.modifyusergroup'), 
                           title=formtitle, subtitle=subtitle, msg='Select MainGroups to visualise for User "{}" and click Submit'.format(user.username))

# Set the route and accepted methods
@mod_blueprint.route('/user/modifytags', methods=['GET', 'POST'])
@login_required
def modifyusertags():
    """
    Show a table with MainGroups visible to each user
    """
    # only for admin
    role = 2
    if session.get('logged_in'):
        role = session.get('role')
    if role >0: 
        return(redirect(url_for('admin.default')))

    _gid = int(request.args['gid']) if 'gid' in request.args else None

    subtitle = None

    # invalid table request are to be ignored
    formtitle = 'Modify User visible Tags'
    tags = getUsertags(_gid)
    form = UserTagForm(None if request.method=="GET" else request.form, tags=tags, include_what='selection')

    if not _gid is None: # only modify
        form.gid.data = _gid # userid
        user = WDUsers.get_by_id(_gid)
    
    # Verify the sign in form
    valid = True
    if form.validate_on_submit():
        if valid:
            # the elements of the form
            field_dict = {k:v for k,v in request.form.items()}
            doModifyUserTags(field_dict)
            return redirect(url_for('.usergroups')) #doExport(field_dict)
            
    return render_template("waddashboard/usertags.html", form=form, action=url_for('.modifyusertags'), 
                           title=formtitle, subtitle=subtitle, msg='Select Tags to visualise for User "{}" and click Submit'.format(user.username))

def getSelectors(groupid, subgroupid=None):
    """
    Return a list of Selectors in dictionary format, belonging to the given MainGroup or SubGroup
    """
    if groupid is None:
        gid   = subgroupid
        model = "subgroups"
    else:
        gid = groupid
        model = "maingroups"
        
    if gid is None:
        in_group = []
    else:
        in_group =[]
        if model == "subgroups":
            items = WDSubGroups.get_by_id(gid).subitems
        else:
            items = WDMainGroups.get_by_id(gid).mainitems
            
        for item in items:
            try:
                in_group.append(item.selector.id)
            except dbio.DBSelectors.DoesNotExist: # happens if a selector was deleted in WAD_Admin
                item.delete_instance(recursive=False)
                
    result = []
    for sel in dbio.DBSelectors.select():
        result.append({'sel_name':sel.name,
                       'sel_description':sel.description,
                       'sel_isactive':sel.isactive,
                       'sel_selected':sel.id in in_group,
                       'sid': sel.id})
        
    return result

def getSubgroups(gid):
    """
    Return a list of Subgroups in dictionary format, belonging to the given MainGroup
    """
    result = []
    if gid is None:
        in_group = []
    else:
        group = WDMainGroups.get_by_id(gid)
        in_group = [it.subgroup.id for it in WDMainItems.select().where(WDMainItems.maingroup == group)]

    for sub in WDSubGroups.select():
        result.append({'sub_name':sub.name,
                       'sub_description':sub.description,
                       'sub_selected':sub.id in in_group,
                       'sub_id': sub.id})
        
    return sorted(result, key=lambda x:x['sub_name'])

def getUsergroups(gid):
    """
    Return a list of Maingroups in dictionary format, with visibility status for specified user
    """
    result = []
    if gid is None:
        in_group = []
    else:
        user = WDUsers.get_by_id(gid)
        in_group = [it.maingroup.id for it in WDUserGroups.select().where(WDUserGroups.user == user)]

    for sub in WDMainGroups.select():
        result.append({'grp_name':sub.name,
                       'grp_description':sub.description,
                       'grp_selected':sub.id in in_group,
                       'grp_id': sub.id,
                       'grp_section': sub.section.name})
        
    return sorted(result, key=lambda x:x['grp_name'])

def getUsertags(gid):
    """
    Return a list of tags visible to the user
    """
    result = []
    if gid is None:
        in_group = []
    else:
        user = WDUsers.get_by_id(gid)
        in_group = [it.tag.id for it in WDUserTags.select().where(WDUserTags.user == user)]

    for sub in dbio.DBDataTags.select():
        result.append({'tag_name':sub.name,
                       'tag_selected':sub.id in in_group,
                       'tag_id': sub.id})
        
    return sorted(result, key=lambda x:x['tag_id'])

def doModifySection(field_dict):
    if field_dict['gid'] == '':
        # create new
        mid = WDSections.create(name=field_dict['name'], description=field_dict['description'], position=field_dict['position'])
    else:
        gid = int(field_dict['gid'])
        section = WDSections.get_by_id(gid)
        section.name = field_dict['name']
        section.description = field_dict['description']
        section.position = field_dict['position']
        section.save()

def doModifyGroup(field_dict):
    sidsuffix = '-sub_id'
    subsuffix = '-sub_selected'
    sub_ids = []
    for key, entry in field_dict.items():
        if key.endswith(subsuffix): # it's either marked and present or not present
            sidkey = key[:(len(key)-len(subsuffix))]+sidsuffix
            sub_ids.append(int(field_dict[sidkey]))
    
    sid = int(field_dict['section'])
    if sid == 0:
        # create new
        sid = WDSections.create(name=field_dict['newsectionname'], description=field_dict['newsectiondescription'])
    else:
        sid = WDSections.get_by_id(sid)
        
    if field_dict['gid'] == '':
        # create new
        mid = WDMainGroups.create(name=field_dict['name'], description=field_dict['description'], section=sid)
        for i in sub_ids:
            WDMainItems.create(subgroup=i, maingroup=mid)
    else:
        gid = int(field_dict['gid'])
        group = WDMainGroups.get_by_id(gid)
        group.section = sid
        group.name = field_dict['name']
        group.description = field_dict['description']
        group.save()
        for i in WDMainItems.select().where(WDMainItems.maingroup == group):
            i.delete_instance(recursive=False)
                
        for i in sub_ids:
            WDMainItems.create(subgroup=i, maingroup=group)
            
def doModifySubGroup(field_dict):
    sidsuffix = '-sid'
    selsuffix = '-sel_selected'
    sel_ids = []
    for key, entry in field_dict.items():
        if key.endswith(selsuffix): # it's either marked and present or not present
            sidkey = key[:(len(key)-len(selsuffix))]+sidsuffix
            sel_ids.append(int(field_dict[sidkey]))
    
    if field_dict['gid'] == '':
        # create new
        mid = WDSubGroups.create(name=field_dict['name'], description=field_dict['description'])
        for i in sel_ids:
            WDSubItems.create(selector=i, subgroup=mid)
    else:
        gid = int(field_dict['gid'])
        subgroup = WDSubGroups.get_by_id(gid)
        subgroup.name = field_dict['name']
        subgroup.description = field_dict['description']
        subgroup.save()
        for i in subgroup.subitems:
            i.delete_instance(recursive=False)
                
        for i in sel_ids:
            WDSubItems.create(selector=i, subgroup=gid)
            
def doModifyUserGroup(field_dict):
    iw = field_dict['include_what']
    if iw == "all":
        grp_ids = [ f.id for f in WDMainGroups.select() ]
    elif iw == "none":
        grp_ids = []
    else: #iw == "selection":
        sidsuffix = '-grp_id'
        grpsuffix = '-grp_selected'
        grp_ids = []
        for key, entry in field_dict.items():
            if key.endswith(grpsuffix): # it's either marked and present or not present
                sidkey = key[:(len(key)-len(grpsuffix))]+sidsuffix
                grp_ids.append(int(field_dict[sidkey]))

    gid = int(field_dict['gid'])
    user = WDUsers.get_by_id(gid)
    for i in WDUserGroups.select().where(WDUserGroups.user == user):
        i.delete_instance(recursive=False)
            
    for i in grp_ids:
        WDUserGroups.create(user=user, maingroup=WDMainGroups.get_by_id(i))
            
def doModifyUserTags(field_dict):
    iw = field_dict['include_what']
    if iw == "all":
        tag_ids = [ f.id for f in dbio.DBDataTags.select() ]
    elif iw == "none":
        tag_ids = []
    else: #iw == "selection":
        sidsuffix = '-tag_id'
        tagsuffix = '-tag_selected'
        tag_ids = []
        for key, entry in field_dict.items():
            if key.endswith(tagsuffix): # it's either marked and present or not present
                sidkey = key[:(len(key)-len(tagsuffix))]+sidsuffix
                tag_ids.append(int(field_dict[sidkey]))

    gid = int(field_dict['gid'])
    user = WDUsers.get_by_id(gid)
    for i in WDUserTags.select().where(WDUserTags.user == user):
        i.delete_instance(recursive=False)
            
    for i in tag_ids:
        WDUserTags.create(user=user, tag=dbio.DBDataTags.get_by_id(i))
            
