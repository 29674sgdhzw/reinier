# Import Form
from flask_wtf import FlaskForm 

# Import Form elements such as StringField and BooleanField (optional)
from wtforms import StringField, FileField, HiddenField, SelectField # BooleanField

# Import Form validators
from wtforms.validators import InputRequired, NoneOf

class ModifyForm(FlaskForm):
    metafile = FileField('Meta file', [ ])  
    
    